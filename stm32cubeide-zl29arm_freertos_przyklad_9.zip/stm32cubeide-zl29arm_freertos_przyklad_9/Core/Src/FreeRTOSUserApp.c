/**
 * @file
 *
 * @brief Tworzenie zadan w systemie FreeRTOS
 *        debugowanie
 */

#include "FreeRTOSUserApp.h"

// FreeRTOSConfig.h
// #define configUSE_APPLICATION_TASK_TAG 1
// makra musza byc przed dodaniem pliku FreeRTOS.h

void vSetTracePin (int tcb)
{
	switch(tcb)
	{
		case 1:
		        HAL_GPIO_WritePin(Task1_GPIO_Port, Task1_Pin, SET);
		        break;
	    case 2:
		        HAL_GPIO_WritePin(Task2_GPIO_Port, Task2_Pin, SET);
		        break;
	    case 3:
		        HAL_GPIO_WritePin(Task0_GPIO_Port, Task0_Pin, SET);
		        break;
		default:
	}
}

void vResetTracePin (int tcb)
{
	switch(tcb)
	{
		case 1:
		        HAL_GPIO_WritePin(Task1_GPIO_Port, Task1_Pin, RESET);
		        break;
	    case 2:
		        HAL_GPIO_WritePin(Task2_GPIO_Port, Task2_Pin, RESET);
		        break;
	    case 3:
		        HAL_GPIO_WritePin(Task0_GPIO_Port, Task0_Pin, RESET);
		        break;
		default:
	}

}


int __io_putchar(int ch)
{
	ITM_SendChar(ch);
	return(ch);
}

static void vTask_LED1(void* prvParameters)
{
	vTaskSetApplicationTaskTag( NULL, ( void * ) 1 );

	for(;;)
	{
		//driverLED_toggle(LED1);
		//ITM_SendChar('X');
		//printf("zadanie1\n");
		vTaskDelay(2 / portTICK_PERIOD_MS);
	}
}


static void vTask_LED2(void* prvParameters)
{
	vTaskSetApplicationTaskTag( NULL, ( void * ) 2 );

	for(;;)
	{
		//driverLED_toggle(LED2);
		//ITM_SendChar('.');
		//printf("ZADANIE2\n");
		vTaskDelay(1 / portTICK_PERIOD_MS);
	}
}

void vApplicationIdleHook(void)
{
	vTaskSetApplicationTaskTag( NULL, ( void * ) 3 );

	for(;;)
	{
		//taskYIELD();
	}
}

void FreeRTOSUserApp(void)
{
	driverLED_init();
	//setbuf(stdout, NULL);

	xTaskCreate(vTask_LED1,
			    "TaskLED1",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY + 1,
				NULL);

	xTaskCreate(vTask_LED2,
			    "TaskLED2",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY + 1,
				NULL);

	vTaskStartScheduler();

	for(;;)
	{
	}
}
