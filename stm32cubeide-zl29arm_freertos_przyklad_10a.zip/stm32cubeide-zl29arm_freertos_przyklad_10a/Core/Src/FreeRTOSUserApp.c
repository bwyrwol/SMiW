/**
 * @file
 *
 * @brief Tworzenie zadan w systemie FreeRTOS
 *        Programowe odmierzanie czasu za pomoca Timerow
 */

#include "FreeRTOSUserApp.h"

TimerHandle_t Timer1Handle, Timer2Handle;

static void vTaskTimer(TimerHandle_t xTimer)
{
	uint32_t ulTimerID;

	ulTimerID = (uint32_t) pvTimerGetTimerID(xTimer);

	if (ulTimerID == 1)
		driverLED_toggle(LED1);
	else if (ulTimerID == 2)
		driverLED_toggle(LED2);
}


static void vTask(void* prvParameters)
{
	for(;;)
	{
		vTaskDelay(100 / portTICK_PERIOD_MS);
	}
}


void FreeRTOSUserApp(void)
{
	driverLED_init();

	Timer1Handle = xTimerCreate(
	                     "Timer1", 						// nazwa licznika, podobnie jak w zadaniu
	                     (200 / portTICK_PERIOD_MS), 	// opoznienie w tickach systemowych
	                     pdTRUE, 						// automatyczne przeladowanie
	                     ( void * ) 1,					// ID licznika, po tym numerze jest identyfikowany
	                     vTaskTimer						// wywolywana funkcja co okreslony czas
	                   	   	   );

	Timer2Handle = xTimerCreate(
	                     "Timer2", 						// nazwa licznika, podobnie jak w zadaniu
	                     (202 / portTICK_PERIOD_MS), 	// opoznienie w tickach systemowych
	                     pdTRUE, 						// automatyczne przeladowanie
	                     ( void * ) 2,					// ID licznika, po tym numerze jest identyfikowany
	                     vTaskTimer						// wywolywana funkcja co okreslony czas
	                   	   	   );

	xTaskCreate(vTask,
			    "Task",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY + 1,
				NULL);

	xTimerStart(Timer1Handle, 0);
	xTimerStart(Timer2Handle, 0);
	vTaskStartScheduler();

	for(;;)
	{
	}
}
