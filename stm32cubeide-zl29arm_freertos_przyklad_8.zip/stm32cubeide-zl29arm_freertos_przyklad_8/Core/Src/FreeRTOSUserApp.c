/**
 * Wspoldzielenie zasobow
 * 
 * wersja bez zabezpieczen dostepu do zasobu
 */

#include "FreeRTOSUserApp.h"

static void vTask1(void* prvParameters)
{
	uint8_t tekst[] = "................";

	for(;;)
	{
		LCD_GoTo(0, 0);
		LCD_WriteText(tekst);

		driverLED_toggle(LED1);
		vTaskDelay(500 / portTICK_PERIOD_MS);
	}
}


static void vTask2(void* prvParameters)
{
	uint8_t tekst[] = "xxxxxxxxxxxxxxxx";

	for(;;)
	{
		LCD_GoTo(0, 1);
		LCD_WriteText(tekst);

		driverLED_toggle(LED2);
		vTaskDelay(500 / portTICK_PERIOD_MS);
	}
}


void FreeRTOSUserApp(void)
{
	driverLED_init();
	LCD_Initialize();

	xTaskCreate(vTask1,
			    "Task1",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY + 1,
				NULL);

	xTaskCreate(vTask2,
			    "Task2",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY + 1,
				NULL);

	vTaskStartScheduler();

	for(;;)
	{
	}
}
