#ifndef FREERTOSUSERAPP_H
#define FREERTOSUSERAPP_H

#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "driverLED.h"
#include "semphr.h"
#include "lcd_hd44780_lib.h"

#ifndef tskIDLE_PRIORITY
#define tskIDLE_PRIORITY 0
#endif

void FreeRTOSUserApp(void) __attribute((noreturn));

#endif//FREERTOSUSERAPP_H
