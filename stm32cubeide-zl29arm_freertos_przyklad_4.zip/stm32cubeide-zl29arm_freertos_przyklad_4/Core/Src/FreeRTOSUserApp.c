#include "FreeRTOSUserApp.h"

static xQueueHandle xQueueKeys;

static void vTask_KEY(void* prvParameters)
{
    static uint8_t keys_state, keys_state_prev;
    static uint8_t keys_state_pressed, keys_state_pressed_prev;

    for(;;)
    {
	vTaskDelay(10 / portTICK_PERIOD_MS);




    }
}


static void vTask_LED2(void* prvParameters)
{
    uint8_t keys_state;

    for(;;)
    {
	if (xQueueReceive(xQueueKeys, &keys_state, portMAX_DELAY) == pdTRUE)
	{
	    if ((keys_state & SW3) != 0) driverLED_toggle(LED1);
	    if ((keys_state & SW4) != 0) driverLED_toggle(LED2);
	}
    }
}


void FreeRTOSUserApp(void)
{
	driverLED_init();
	driverKEY_init();

	xQueueKeys = xQueueCreate(5, sizeof(uint8_t));

	xTaskCreate(vTask_KEY,
			    "TaskKEY",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY + 1,
				NULL);

	xTaskCreate(vTask_LED2,
			    "TaskLED2",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY + 1,
				NULL);

	vTaskStartScheduler();

	for(;;)
	{
	}
}
