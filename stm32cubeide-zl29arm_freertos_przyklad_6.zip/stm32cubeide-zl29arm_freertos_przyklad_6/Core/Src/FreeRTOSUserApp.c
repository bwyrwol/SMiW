/**
 * Przyklad uzycia wspolprogramow
 * przekazywanie danych przez kolejke
 */

#include "FreeRTOSUserApp.h"

QueueHandle_t CoRoutineQueueHandle;

void vApplicationIdleHook(void)
{
	vCoRoutineSchedule();
}

static void vLEDcr(xCoRoutineHandle xHandle, unsigned portBASE_TYPE uxIndex);
static void vLEDcr(xCoRoutineHandle xHandle, unsigned portBASE_TYPE uxIndex)
{
	static uint8_t counter = 0;
	static BaseType_t xResult;

	crSTART(xHandle);

	for( ;; )
	{
		crQUEUE_RECEIVE( xHandle,
			         CoRoutineQueueHandle,
				 &counter,
		                 portMAX_DELAY,
				 &xResult );

		if( xResult == pdPASS )
		{
		    driverLED_toggle(LED1);
		    driverLED_toggle(LED2);
		}
	}

	crEND();
}

#define NO_DELAY 0

static void vTIMERcr(xCoRoutineHandle xHandle, unsigned portBASE_TYPE uxIndex);
static void vTIMERcr(xCoRoutineHandle xHandle, unsigned portBASE_TYPE uxIndex)
{
	static uint8_t counter = 0;
	static BaseType_t xResult;

	crSTART(xHandle);

	for( ;; )
	{
		crDELAY(xHandle, 200 / portTICK_RATE_MS);

		crQUEUE_SEND( xHandle,
			      oRoutineQueueHandle,
		              &counter,
		              NO_DELAY,
			      &xResult );
		counter++;
	}
	crEND();
}


void FreeRTOSUserApp(void)
{
	driverLED_init();

	xCoRoutineCreate(vLEDcr, 0, 0);
	xCoRoutineCreate(vTIMERcr, 0, 0);
	CoRoutineQueueHandle = xQueueCreate(5, 1);

	vTaskStartScheduler();

	for(;;)
	{
	}
}
