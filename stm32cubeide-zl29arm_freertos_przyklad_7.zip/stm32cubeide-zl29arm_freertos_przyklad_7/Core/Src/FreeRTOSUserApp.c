/**
 * Przyklad uzycia semaforow binarnych (deadlock)
 *
 * uwaga na configUSE_16_BIT_TICKS
 */

#include "FreeRTOSUserApp.h"

xSemaphoreHandle semBin1Handle;
xSemaphoreHandle semBin2Handle;

static void vTask_LED1(void* prvParameters)
{
	for(;;)
	{
		xSemaphoreTake(semBin1Handle, portMAX_DELAY);
		//*******
		for (volatile uint16_t delay = 0; delay < 10000; delay++);
		//*******
		xSemaphoreTake(semBin2Handle, portMAX_DELAY);

		driverLED_toggle(LED1);
		xSemaphoreGive(semBin1Handle);
		xSemaphoreGive(semBin2Handle);
		vTaskDelay(200 / portTICK_PERIOD_MS);
	}
}


static void vTask_LED2(void* prvParameters)
{
	for(;;)
	{
		xSemaphoreTake(semBin2Handle, portMAX_DELAY);
		xSemaphoreTake(semBin1Handle, portMAX_DELAY);

		driverLED_toggle(LED2);
		xSemaphoreGive(semBin2Handle);
		xSemaphoreGive(semBin1Handle);
		vTaskDelay(200 / portTICK_PERIOD_MS);
	}
}


void FreeRTOSUserApp(void)
{
	driverLED_init();

	vSemaphoreCreateBinary(semBin1Handle);
	vSemaphoreCreateBinary(semBin2Handle);
	//xSemaphoreTake(semBin1Handle, 0);
	//xSemaphoreTake(semBin2Handle, 0);
	xSemaphoreGive(semBin1Handle);
	xSemaphoreGive(semBin2Handle);

	xTaskCreate(vTask_LED1,
			    "TaskLED1",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY + 1,
				NULL);

	xTaskCreate(vTask_LED2,
			    "TaskLED2",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY + 1,
				NULL);

	vTaskStartScheduler();

	for(;;)
	{
	}
}
