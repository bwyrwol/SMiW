#include "driverLED.h"

void driverLED_toggle(uint16_t led)
{
	HAL_GPIO_TogglePin(LED2_GPIO_Port, led);
}

void driverLED_init(void)
{
	#warning GPIO port dla diod LEDs zainicjowany przez HAL (MX_GPIO_Init())
}
