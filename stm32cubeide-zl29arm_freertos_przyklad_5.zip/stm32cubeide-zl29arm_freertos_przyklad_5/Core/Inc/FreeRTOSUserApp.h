#ifndef FREERTOSUSERAPP_H
#define FREERTOSUSERAPP_H

#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "driverLED.h"
#include "driverKEY.h"
#include "queue.h"

#ifndef tskIDLE_PRIORITY
#define tskIDLE_PRIORITY 0
#endif

void FreeRTOSUserApp(void) __attribute((noreturn));
void HAL_TIM_PeriodElapsedCallback_TIM6(void);

#endif//FREERTOSUSERAPP_H
