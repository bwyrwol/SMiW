/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define SW4_Pin GPIO_PIN_13
#define SW4_GPIO_Port GPIOC
#define JOY_U_Pin GPIO_PIN_5
#define JOY_U_GPIO_Port GPIOC
#define LED7Disp0_Pin GPIO_PIN_1
#define LED7Disp0_GPIO_Port GPIOB
#define LED2_Pin GPIO_PIN_14
#define LED2_GPIO_Port GPIOE
#define LED3_Pin GPIO_PIN_15
#define LED3_GPIO_Port GPIOE
#define LED7Disp3_Pin GPIO_PIN_14
#define LED7Disp3_GPIO_Port GPIOB
#define JOY_D_Pin GPIO_PIN_6
#define JOY_D_GPIO_Port GPIOC
#define JOY_R_Pin GPIO_PIN_7
#define JOY_R_GPIO_Port GPIOC
#define JOY_L_Pin GPIO_PIN_8
#define JOY_L_GPIO_Port GPIOC
#define JOY_OK_Pin GPIO_PIN_9
#define JOY_OK_GPIO_Port GPIOC
#define SW3_Pin GPIO_PIN_12
#define SW3_GPIO_Port GPIOC
#define LED7SegA_Pin GPIO_PIN_0
#define LED7SegA_GPIO_Port GPIOD
#define LED7SegB_Pin GPIO_PIN_1
#define LED7SegB_GPIO_Port GPIOD
#define LED7SegC_Pin GPIO_PIN_2
#define LED7SegC_GPIO_Port GPIOD
#define LED7SegD_Pin GPIO_PIN_3
#define LED7SegD_GPIO_Port GPIOD
#define LED7SegE_Pin GPIO_PIN_4
#define LED7SegE_GPIO_Port GPIOD
#define LED7SegF_Pin GPIO_PIN_5
#define LED7SegF_GPIO_Port GPIOD
#define LED7SegG_Pin GPIO_PIN_6
#define LED7SegG_GPIO_Port GPIOD
#define LED7SegPD_Pin GPIO_PIN_7
#define LED7SegPD_GPIO_Port GPIOD
#define LED7Disp1_Pin GPIO_PIN_5
#define LED7Disp1_GPIO_Port GPIOB
#define LED7Disp2_Pin GPIO_PIN_9
#define LED7Disp2_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */
//#define LED7Segments_GPIO_Port GPIOD
#define FREERTOS_USER_APP

void StartTimer_TIM6(void);
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
