#ifndef DRIVERLED7SEG_H
#define DRIVERLED7SEG_H

#include <stdint.h>
#include "main.h"

#define NUMBER_OF_DIGITS 4
#define LED_DISPLAY_OFF  0xFF
#define LED_DISPLAY_0	 0
#define LED_DISPLAY_1	 1
#define LED_DISPLAY_2	 2
#define LED_DISPLAY_3	 3

void driverLED7seg_init(void);
void driverLED7seg_refresh(void);

void driverLED7seg_display(uint8_t display, uint8_t segments);
uint8_t driverLED7seg_bcd_to_7seg(uint8_t bcd);

#endif//DRIVERLED7SEG_H
