/**
 * obsluga wyswietlacza 7-segmentowego LED (przerwanie)
 * obsluga klawiatury
 * wykorzystanie kolejki
 */


#include "FreeRTOSUserApp.h"
#include "driverLED7Seg.h"

static xQueueHandle xQueueKeys;

void HAL_TIM_PeriodElapsedCallback_TIM6(void)
{
	driverLED7seg_refresh();
}

static void vTask_KEY(void* prvParameters)
{
	static uint8_t keys_state, keys_state_prev;
	static uint8_t keys_state_pressed, keys_state_pressed_prev;

	for(;;)
	{
		vTaskDelay(10 / portTICK_PERIOD_MS);

		keys_state = driverKEY_read();

		keys_state_pressed = (~(keys_state ^ keys_state_prev)) & keys_state; // pressed keys

		if (keys_state_pressed == KEYS_RELEASED) // all keys released
		{

		}
		else
		{
			if ((~keys_state_pressed_prev & keys_state_pressed) != KEYS_RELEASED) // new key pressed
			{
				// key_state_pressed
				xQueueSend(xQueueKeys, &keys_state_pressed, portMAX_DELAY);
			}
			else // can be used for auto-repeat
			{
				// key_state_pressed
			}
		}

		keys_state_pressed_prev = keys_state_pressed;
		keys_state_prev = keys_state;
	}
}


static void vTask_LED7Seg(void* prvParameters)
{
	uint8_t keys_state;
	uint16_t counter = 0;

	driverLED7seg_display(LED_DISPLAY_3, driverLED7seg_bcd_to_7seg(0));
	driverLED7seg_display(LED_DISPLAY_2, driverLED7seg_bcd_to_7seg(0));
	driverLED7seg_display(LED_DISPLAY_1, driverLED7seg_bcd_to_7seg(0));
	driverLED7seg_display(LED_DISPLAY_0, driverLED7seg_bcd_to_7seg(0));

	for(;;)
	{
		if (xQueueReceive(xQueueKeys, &keys_state, portMAX_DELAY) == pdTRUE)
		{





		}
	}
}


void FreeRTOSUserApp(void)
{
	driverLED_init();
	driverKEY_init();
	driverLED7seg_init();

	xQueueKeys = xQueueCreate(5, sizeof(uint8_t));

	xTaskCreate(vTask_KEY,
			    "TaskKEY",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY + 1,
				NULL);

	xTaskCreate(vTask_LED7Seg,
			    "TaskLED7S",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY + 1,
				NULL);

	StartTimer_TIM6();
	vTaskStartScheduler();

	for(;;)
	{
	}
}
