
#include "driverLED7Seg.h"

#define NUMBER_OF_SYMBOLS 11

static const
uint8_t seg7table[NUMBER_OF_SYMBOLS] =
                      { 0b00111111, // 0     +---a---+
                        0b00000110, // 1     |       |
		        0b01011011, // 2     f       b
			0b01001111, // 3     |       |
			0b01100110, // 4     +---g---+
	                0b01101101, // 5     |       |
			0b01111101, // 6     e       c
			0b00000111, // 7     |       |
			0b01111111, // 8     +---d---+ PD
			0b01101111, // 9
			0b01000000  // -
                      };

static uint8_t driver7Seg_displays[NUMBER_OF_DIGITS];

void driverLED7seg_init(void)
{
	#warning Porty dla wyswietlacza 7-segmentowego zainicjowane przez HAL
}


static void driverLED7seg_sel_display(uint8_t display) // aktywny stan WYSOKI
{
	HAL_GPIO_WritePin(LED7Disp0_GPIO_Port, LED7Disp0_Pin, RESET);
	HAL_GPIO_WritePin(LED7Disp1_GPIO_Port, LED7Disp1_Pin, RESET);
	HAL_GPIO_WritePin(LED7Disp2_GPIO_Port, LED7Disp2_Pin, RESET);
	HAL_GPIO_WritePin(LED7Disp3_GPIO_Port, LED7Disp3_Pin, RESET);

	switch(display)
	{
		case LED_DISPLAY_0:
			HAL_GPIO_WritePin(LED7Disp0_GPIO_Port, LED7Disp0_Pin, SET);
			break;
		case LED_DISPLAY_1:
			HAL_GPIO_WritePin(LED7Disp1_GPIO_Port, LED7Disp1_Pin, SET);
			break;
		case LED_DISPLAY_2:
			HAL_GPIO_WritePin(LED7Disp2_GPIO_Port, LED7Disp2_Pin, SET);
			break;
		case LED_DISPLAY_3:
			HAL_GPIO_WritePin(LED7Disp3_GPIO_Port, LED7Disp3_Pin, SET);
			break;
		default:
	}
}


static void driverLED7seg_set_segments(uint8_t segments) // active low
{
	if ((segments & 0b00000001) != 0) // segment a
		HAL_GPIO_WritePin(LED7SegA_GPIO_Port, LED7SegA_Pin, RESET);
	else
		HAL_GPIO_WritePin(LED7SegA_GPIO_Port, LED7SegA_Pin, SET);

	if ((segments & 0b00000010) != 0) // segment b
		HAL_GPIO_WritePin(LED7SegB_GPIO_Port, LED7SegB_Pin, RESET);
	else
		HAL_GPIO_WritePin(LED7SegB_GPIO_Port, LED7SegB_Pin, SET);

	if ((segments & 0b00000100) != 0) // segment c
		HAL_GPIO_WritePin(LED7SegC_GPIO_Port, LED7SegC_Pin, RESET);
	else
		HAL_GPIO_WritePin(LED7SegC_GPIO_Port, LED7SegC_Pin, SET);

	if ((segments & 0b00001000) != 0) // segment d
		HAL_GPIO_WritePin(LED7SegD_GPIO_Port, LED7SegD_Pin, RESET);
	else
		HAL_GPIO_WritePin(LED7SegD_GPIO_Port, LED7SegD_Pin, SET);

	if ((segments & 0b00010000) != 0) // segment e
		HAL_GPIO_WritePin(LED7SegE_GPIO_Port, LED7SegE_Pin, RESET);
	else
		HAL_GPIO_WritePin(LED7SegE_GPIO_Port, LED7SegE_Pin, SET);

	if ((segments & 0b00100000) != 0) // segment f
		HAL_GPIO_WritePin(LED7SegF_GPIO_Port, LED7SegF_Pin, RESET);
	else
		HAL_GPIO_WritePin(LED7SegF_GPIO_Port, LED7SegF_Pin, SET);

	if ((segments & 0b01000000) != 0) // segment g
		HAL_GPIO_WritePin(LED7SegG_GPIO_Port, LED7SegG_Pin, RESET);
	else
		HAL_GPIO_WritePin(LED7SegG_GPIO_Port, LED7SegG_Pin, SET);

	if ((segments & 0b10000000) != 0) // segment pd
		HAL_GPIO_WritePin(LED7SegPD_GPIO_Port, LED7SegPD_Pin, RESET);
	else
		HAL_GPIO_WritePin(LED7SegPD_GPIO_Port, LED7SegPD_Pin, SET);
}

void driverLED7seg_refresh(void)
{
    static uint8_t driverLED7seg_ptr = 0;

    if ((++driverLED7seg_ptr) > NUMBER_OF_DIGITS)
    	driverLED7seg_ptr = 0;

    driverLED7seg_sel_display(LED_DISPLAY_OFF);
    driverLED7seg_set_segments(driver7Seg_displays[driverLED7seg_ptr]);
    driverLED7seg_sel_display(driverLED7seg_ptr);
}


void driverLED7seg_display(uint8_t display, uint8_t segments)
{
  //if (display < NUMBER_OF_DIGITS)
  driver7Seg_displays[display] = segments;
}


uint8_t driverLED7seg_bcd_to_7seg(uint8_t bcd)
{
	if (bcd < NUMBER_OF_SYMBOLS)
		return seg7table[bcd];
	else
		return 0;
}

