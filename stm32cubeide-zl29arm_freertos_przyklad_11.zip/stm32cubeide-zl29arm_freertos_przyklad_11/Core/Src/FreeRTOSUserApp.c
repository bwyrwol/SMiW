/**
 * @file
 *
 * @brief Tworzenie zadan w systemie FreeRTOS
 *        statystyki
 */

#include "FreeRTOSUserApp.h"

uint32_t RTOS_RunTimeCounter = 0;

void HAL_TIM_PeriodElapsedCallback_TIM6(void)
{
	RTOS_RunTimeCounter++;
}

void RTOS_AppConfigureTimerForRuntimeStats(void)
{
  RTOS_RunTimeCounter = 0;
  StartTimer_TIM6();
}

uint32_t RTOS_AppGetRuntimeCounterValueFromISR(void)
{
  return RTOS_RunTimeCounter;
}


static void vTask_LED1(void* prvParameters)
{
	for(;;)
	{
		driverLED_toggle(LED1);
		for (uint32_t delay = 0; delay < 100000; delay++)
		{
			;
		}
		vTaskDelay(200 / portTICK_PERIOD_MS);
	}
}


static void vTask_LED2(void* prvParameters)
{
	for(;;)
	{
		driverLED_toggle(LED2);
		for (uint32_t delay = 0; delay < 150000; delay++)
		{
			;
		}
		vTaskDelay(100 / portTICK_PERIOD_MS);
	}
}


void FreeRTOSUserApp(void)
{
	driverLED_init();

	xTaskCreate(vTask_LED1,
			    "TaskLED1",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY + 1,
				NULL);

	xTaskCreate(vTask_LED2,
			    "TaskLED2",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY + 1,
				NULL);

	vTaskStartScheduler();

	for(;;)
	{
	}
}
