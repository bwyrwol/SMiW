
#include <avr/io.h>
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "led_port_avr.h"

#define main_TASK_PRIORITY (tskIDLE_PRIORITY + 1)

xQueueHandle Queue;


static void vTaskSendReceive(void *pvParameters);
static void vTaskSendReceive(void *pvParameters)
{


  for(;;)
  {
	//???
  }
}


static void vTaskReceiveSend(void *pvParameters);
static void vTaskReceiveSend(void *pvParameters)
{


  for(;;)
  {
	//???
  }
}


static void prvInitHardware(void);
static void prvInitHardware(void)
{
    led_init();
}


int main(void)
{
	xTaskCreate(vTaskSendReceive,
	            (const int8_t*)"sr",
	            configMINIMAL_STACK_SIZE,
	            NULL,
	            main_TASK_PRIORITY,
	            NULL);

	xTaskCreate(vTaskReceiveSend,
	            (const int8_t*) "rs",
	            configMINIMAL_STACK_SIZE,
	            NULL,
	            main_TASK_PRIORITY,
	            NULL);
              
    Queue = xQueueCreate(5, sizeof(uint8_t));
	uint8_t data_send = 'S';
	xQueueSend(Queue, &data_send, portMAX_DELAY);

	prvInitHardware();
	vTaskStartScheduler();

    while (1) 
    {
    }
}

