
#include <avr/io.h>
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "led_port_avr.h"
#include "timer.h"

#define main_TASK_PRIORITY (tskIDLE_PRIORITY + 1)

xQueueHandle QueueTime;

#define TASK1 1
#define TASK2 2
#define TASK3 3

static void vLED1(void *pvParameters);
static void vLED1(void *pvParameters)
{
  //(void) pvParameters;
  
  for(;;)
  {
	//???
  }
}

static void vLED2(void *pvParameters);
static void vLED2(void *pvParameters)
{
  //(void) pvParameters;

  for(;;)
  {
	//???
  }
}

static void vLED3(void *pvParameters);
static void vLED3(void *pvParameters)
{
  //(void) pvParameters;

  for(;;)
  {
	//???
  }
}


void timer_callback(void)
{
  static uint8_t time_200ms = 0;
  static uint8_t time_201ms = 0;
  static uint8_t time_202ms = 0;
  
  uint8_t task_no;
  
  signed portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;

  if (++time_200ms == 200)
  {
    time_200ms = 0;
    task_no = TASK1;
    xQueueSendToBackFromISR(QueueTime, &task_no, &xHigherPriorityTaskWoken);
  }
  
  if (++time_201ms == 201)
  {
    time_201ms = 0;
    task_no = TASK2;
    xQueueSendToBackFromISR(QueueTime, &task_no, &xHigherPriorityTaskWoken);
  }

  if (++time_202ms == 202)
  {
    time_202ms = 0;
    task_no = TASK3;
    xQueueSendToBackFromISR(QueueTime, &task_no, &xHigherPriorityTaskWoken);
  }
  
  if(xHigherPriorityTaskWoken)
  {
    taskYIELD();
  }
}

static void prvInitHardware(void);
static void prvInitHardware(void)
{
    led_init();
    timer_init();
}


int main(void)
{
	xTaskCreate(vLED1,
	            (const int8_t*)"led1",
	            configMINIMAL_STACK_SIZE,
	            NULL,
	            main_TASK_PRIORITY,
	            NULL);
	
	xTaskCreate(vLED2,
	            (const int8_t*) "led2",
	            configMINIMAL_STACK_SIZE,
	            NULL,
	            main_TASK_PRIORITY,
	            NULL);

	xTaskCreate(vLED3,
	            (const int8_t*) "led3",
	            configMINIMAL_STACK_SIZE,
	            NULL,
	            main_TASK_PRIORITY,
	            NULL);
              
    QueueTime = xQueueCreate(10, sizeof(uint8_t));

	prvInitHardware();

	vTaskStartScheduler();

    while (1) 
    {
    }
}
