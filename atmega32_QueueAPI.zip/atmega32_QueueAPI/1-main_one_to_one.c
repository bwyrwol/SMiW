
#include <avr/io.h>
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "led_port_avr.h"

#define main_TASK_PRIORITY (tskIDLE_PRIORITY + 1)

xQueueHandle Queue;

static void vTaskSend(void *pvParameters);
static void vTaskSend(void *pvParameters)
{
  //(void) pvParameters;
  uint8_t data_to_send = 0xFF;

  for(;;)
  {
    xQueueSendToFront(Queue, &data_to_send, portMAX_DELAY);
    data_to_send ^= 0xF0;
    vTaskDelay(250);
  }
}

static void vTaskReceive(void *pvParameters);
static void vTaskReceive(void *pvParameters)
{
  //(void) pvParameters;
  uint8_t data_received;

  for(;;)
  {
    xQueueReceive(Queue, &data_received, portMAX_DELAY);
    led_set(data_received);
  }
}


static void prvInitHardware(void);
static void prvInitHardware(void)
{
  // diody i przyciski
  led_init();
}


int main(void)
{
	xTaskCreate(vTaskSend,
	            (const int8_t*)"tsks",
	            configMINIMAL_STACK_SIZE,
	            NULL,
	            main_TASK_PRIORITY,
	            NULL);
	
	xTaskCreate(vTaskReceive,
	            (const int8_t*) "tskr",
	            configMINIMAL_STACK_SIZE,
	            NULL,
	            main_TASK_PRIORITY,
	            NULL);
              
	Queue = xQueueCreate(10, sizeof(uint8_t));

	prvInitHardware();

	vTaskStartScheduler();

	while (1) 
	{
	}
}

