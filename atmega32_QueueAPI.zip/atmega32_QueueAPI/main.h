#ifndef MAIN_H
#define MAIN_H

#define F_CPU 16000000UL

#include "led_port_avr.h"
#include <avr/io.h>
#include <util/delay.h>

#define LED_PORT PORTA

#endif//MAIN_H
