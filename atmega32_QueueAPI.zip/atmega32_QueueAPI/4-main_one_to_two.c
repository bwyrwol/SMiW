/*
 * freertos_przyklad.c
 *
 * Created: 17.05.2023 17:32:17
 * Author : BW
 */ 

#include <avr/io.h>
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "led_port_avr.h"

#define main_TASK_PRIORITY (tskIDLE_PRIORITY + 1)

xQueueHandle Queue;

static void vTaskSend(void *pvParameters);
static void vTaskSend(void *pvParameters)
{
  //(void) pvParameters;
  
  uint8_t data_to_send;
  uint8_t time_250ms = 0;
  uint8_t time_240ms = 0;

  for(;;)
  {
    vTaskDelay(10);
    if (++time_240ms == 24)
    {
      time_240ms = 0;
      data_to_send = '1';
      xQueueSendToBack(Queue, &data_to_send, portMAX_DELAY);
    }

    if (++time_250ms == 25)
    {
      time_250ms = 0;
      data_to_send = '2';
      xQueueSendToBack(Queue, &data_to_send, portMAX_DELAY);
    }
  }
}

static void vTaskReceiveA(void *pvParameters);
static void vTaskReceiveA(void *pvParameters)
{
  //(void) pvParameters;
  
  uint8_t data_received;

  for(;;)
  {
    data_received = 0;
    xQueuePeek(Queue, &data_received, portMAX_DELAY); //!!! bez taskYIELD dziala tylko przez chwile ale tylko dla czasu 10! (dla kooperacji)
    if (data_received == '1')
    {
      xQueueReceive(Queue, &data_received, 0);
      led_set(led_get() ^ 0x40);
    }
    //else taskYIELD(); //!!! bez tego zawiesza sie jak rownoczesnie pojawia sie dane w kolejce dla A i B (dla kooperacji musi byc)
  }
}

static void vTaskReceiveB(void *pvParameters);
static void vTaskReceiveB(void *pvParameters)
{
  //(void) pvParameters;
  uint8_t data_received;

  for(;;)
  {
    data_received = 0;
    xQueuePeek(Queue, &data_received, portMAX_DELAY); // bez taskYIELD dziala tylko przez chwile ale tylko dla czasu 10! (dla kooperacji)
    if (data_received == '2')
    {
      xQueueReceive(Queue, &data_received, 0);
      led_set(led_get() ^ 0x20);
    }
    //else taskYIELD(); //!!! bez tego zawiesza sie jak rownoczesnie pojawia sie dane w kolejce dla A i B (dla kooperacji musi byc)
  }
}


static void prvInitHardware(void);
static void prvInitHardware(void)
{
  // diody i przyciski
  led_init();
}


int main(void)
{
	xTaskCreate(vTaskSend,
	            (const int8_t*)"tsks",
	            configMINIMAL_STACK_SIZE,
	            NULL,
	            main_TASK_PRIORITY,
	            NULL);
	
	xTaskCreate(vTaskReceiveA,
	            (const int8_t*)"tskr",
	            configMINIMAL_STACK_SIZE,
	            NULL,
	            main_TASK_PRIORITY,
	            NULL);

	xTaskCreate(vTaskReceiveB,
	            (const int8_t*) "tskr",
	            configMINIMAL_STACK_SIZE,
	            NULL,
	            main_TASK_PRIORITY,
	            NULL);
              
  Queue = xQueueCreate(5, sizeof(uint8_t));

	prvInitHardware();

	vTaskStartScheduler();

  while (1) 
  {
  }
}

