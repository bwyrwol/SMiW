
#include <avr/io.h>
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "led_port_avr.h"

#define main_TASK_PRIORITY (tskIDLE_PRIORITY + 1)

xQueueHandle Queue;


static void vTaskSendA(void *pvParameters);
static void vTaskSendA(void *pvParameters)
{
  //(void) pvParameters;
  
  uint8_t data_to_send = 'A';

  for(;;)
  {
    xQueueSendToFront(Queue, &data_to_send, portMAX_DELAY);
    vTaskDelay(250);
  }
}

static void vTaskSendB(void *pvParameters);
static void vTaskSendB(void *pvParameters)
{
  //(void) pvParameters;
  
  uint8_t data_to_send = 'B';

  for(;;)
  {
    xQueueSendToFront(Queue, &data_to_send, portMAX_DELAY);
    vTaskDelay(255);
  }
}

static void vTaskReceive(void *pvParameters);
static void vTaskReceive(void *pvParameters)
{
  //(void) pvParameters;

  for(;;)
  {
	//???
  }
}


static void prvInitHardware(void);
static void prvInitHardware(void)
{
  led_init();
}


int main(void)
{
	xTaskCreate(vTaskSendA,
	            (const int8_t*)"tsks",
	            configMINIMAL_STACK_SIZE,
	            NULL,
	            main_TASK_PRIORITY,
	            NULL);
	
	xTaskCreate(vTaskSendB,
	            (const int8_t*)"tsks",
	            configMINIMAL_STACK_SIZE,
	            NULL,
	            main_TASK_PRIORITY,
	            NULL);

	xTaskCreate(vTaskReceive,
	            (const int8_t*) "tskr",
	            configMINIMAL_STACK_SIZE,
	            NULL,
	            main_TASK_PRIORITY,
	            NULL);
              
  Queue = xQueueCreate(10, sizeof(uint8_t));

	prvInitHardware();

	vTaskStartScheduler();

  while (1) 
  {
  }
}

