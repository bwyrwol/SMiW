/**
 * Przyklad uzycia semafora binarnego w przerwaniu
 */

#include "FreeRTOSUserApp.h"

xSemaphoreHandle semBinary;

void HAL_TIM_PeriodElapsedCallback_TIM6(void)
{
	signed portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;

	xSemaphoreGiveFromISR(semBinary, &xHigherPriorityTaskWoken);
	portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}


static void vTask_LED(void* prvParameters)
{
	for(;;)
	{
	    if (xSemaphoreTake(semBinary, 101 / portTICK_PERIOD_MS) == pdTRUE)
	    {
		driverLED_toggle(LED1);
	    }
	    else
	    {
		driverLED_toggle(LED2);
	    }
	}
}


void FreeRTOSUserApp(void)
{
	driverLED_init();

	vSemaphoreCreateBinary(semBinary);
	xSemaphoreTake(semBinary, 0);

	xTaskCreate(vTask_LED,
			    "TaskLED",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY + 1,
				NULL);

    StartTimer_TIM6();
	vTaskStartScheduler();

	for(;;)
	{
	}
}
