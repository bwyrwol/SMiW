#include "driverLED.h"

void driverLED_toggle(uint16_t led)
{
	HAL_GPIO_TogglePin(LED2_GPIO_Port, led);
}

void driverLED_on(uint16_t led)
{
	if (led == LED1)
	{
		HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, RESET);
	}

	if (led == LED2)
	{
		HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, RESET);
	}
}

void driverLED_off(uint16_t led)
{
	if (led == LED1)
	{
		HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, SET);
	}

	if (led == LED2)
	{
		HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, SET);
	}
}

void driverLED_init(void)
{
	#warning GPIO port dla diod LEDs zainicjowany przez HAL (MX_GPIO_Init())
}
