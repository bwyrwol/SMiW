/**
 * @file
 *
 * @brief Tworzenie zadan w systemie FreeRTOS
 *        debugowanie
 *        odmierzanie czasu - vTaskDelay vs vTaskDelayUntil
 */

#include "FreeRTOSUserApp.h"

// FreeRTOSConfig.h
// #define configUSE_APPLICATION_TASK_TAG 1
// makra musza byc przed dodaniem pliku FreeRTOS.h

void vSetTracePin (int tcb)
{
	switch(tcb)
	{
		case 1:
		        HAL_GPIO_WritePin(Task1_GPIO_Port, Task1_Pin, SET);
		        break;
	    case 2:
		        HAL_GPIO_WritePin(Task2_GPIO_Port, Task2_Pin, SET);
		        break;
		default:
	}
}

void vResetTracePin (int tcb)
{
	switch(tcb)
	{
		case 1:
		        HAL_GPIO_WritePin(Task1_GPIO_Port, Task1_Pin, RESET);
		        break;
	    case 2:
		        HAL_GPIO_WritePin(Task2_GPIO_Port, Task2_Pin, RESET);
		        break;
		default:
	}

}


static void vTask1(void* prvParameters)
{
	vTaskSetApplicationTaskTag( NULL, ( void * ) 1 );

	//TickType_t xLastWakeTime;

	uint8_t delay = 100;

	//xLastWakeTime = xTaskGetTickCount();
	for(;;)
	{
		for (volatile uint32_t delay = 0; delay < 5100; delay++)
		{
			;
		}
		vTaskDelay(3 / portTICK_PERIOD_MS);
		//vTaskDelayUntil( &xLastWakeTime, 3 / portTICK_PERIOD_MS );

		if (--delay == 0)
		{
			delay = 100;
			driverLED_toggle(LED1);
		}
	}
}


static void vTask2(void* prvParameters)
{
	vTaskSetApplicationTaskTag( NULL, ( void * ) 2 );

	uint8_t delay = 100;

	for(;;)
	{
		vTaskDelay(10 / portTICK_PERIOD_MS);

		if (--delay == 0)
		{
			delay = 100;
			driverLED_toggle(LED2);
		}
	}
}


void vApplicationTickHook(void)
{
	HAL_GPIO_WritePin(Task0_GPIO_Port, Task0_Pin, SET);
	for (volatile uint32_t delay = 0; delay < 10; delay++)
	{
		__asm("nop");
	}
	HAL_GPIO_WritePin(Task0_GPIO_Port, Task0_Pin, RESET);
}


void FreeRTOSUserApp(void)
{
	driverLED_init();

	xTaskCreate(vTask1,
			    "Task1",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY + 1,
				NULL);

	xTaskCreate(vTask2,
			    "Task2",
				configMINIMAL_STACK_SIZE,
				NULL,
				tskIDLE_PRIORITY + 1,
				NULL);

	vTaskStartScheduler();

	for(;;)
	{
	}
}
